class Guesser
{
public:
    Guesser();
    int MakeGuess(int Guess);

private:
    int TargetValue;
};

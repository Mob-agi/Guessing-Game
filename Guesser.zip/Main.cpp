#include <iostream>
#include <cstdlib>
#include "Guesser.h"
Guesser::Guesser()
      :TargetValue(1+(rand()%15))
{}
int Guesser::MakeGuess(int Guess)
{
    if (Guess==TargetValue)
    {
        std::cout<<"You got it!  Lucky you!  I'm outta here!";
        return true;
    }
    else if (Guess==0)
    {
        std::cout<<"Who would ever pick zero?  That would be cheating or something!"<<std::endl;
        std::cout<<"Just for that I'm going to think up a new number for you!"<<std::endl;
        this->TargetValue=1+(rand()%15);
        return false;
    }
   else if (Guess!=TargetValue)
    {
        std::cout<<"Nope!  That's not it!"<<std::endl;
        return false;
    }
    
    
    return 0;
}
